%% Canny Edge Detection
clear all;
close all;
clc; clf;
step = 0;

FILTER_SIZE = 5;
SIGMA = 14;

LOW_THRESHOLD_FACTOR = 0.1;
HIGH_THRESHOLD_FACTOR = 0.3;

im = imread('building.tif');
im = double(im);
step = step + 1;
figure(step);

gaussian_filter = fspecial('gaussian', FILTER_SIZE, SIGMA);

conv_im = conv2(im, gaussian_filter, 'same');
step = step + 1;
figure (step);

[gaussian_filter_x gaussian_filter_y] = gradient(gaussian_filter);
im_gradient_x = conv2(conv_im, gaussian_filter_x, 'same');
im_gradient_y = conv2(conv_im, gaussian_filter_y, 'same');
n_direction = atan2(im_gradient_y, im_gradient_x);
n_direction = n_direction*180/pi;

n_direction_dis = zeros(512, 512);
for i = l:512
    for j = 1:512
        if ((n_direction(i, j) > 0) && (n_direction(i, j) < 22.5) || (n_direction(i, j) > 157.5) && (n_direction(i, j) < -157.5))
            n_direction_dis(i, j) = 0;
        end